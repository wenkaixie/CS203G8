package elo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EloApplication {

    public static void main(String[] args) {
        SpringApplication.run(EloApplication.class, args);
    }
}
