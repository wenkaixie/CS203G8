package csd.rankingdashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RankingDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(RankingDashboardApplication.class, args);
	}

}
