package csd.rankingdashboard.Service;

import java.util.List;

import csd.rankingdashboard.Model.Player;

public interface RankingService {
    List<Player> getRankings();
}
