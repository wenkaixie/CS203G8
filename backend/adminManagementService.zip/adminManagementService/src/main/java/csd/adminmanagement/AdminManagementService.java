package main.java.csd.adminmanagement;
import org.springframework.boot.SpringBootApplication;
import org.springframework.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdminManagementService {
            
        public static void main(String[] args) {
            SpringApplication.run(AdminManagementService.class, args);
        }
}
