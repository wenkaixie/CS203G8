package elo;

import elo.Configuration.FirebaseConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EloApplication {
    public static void main(String[] args) {
        FirebaseConfig.initializeFirebaseApp();
        SpringApplication.run(EloApplication.class, args);
    }
}
